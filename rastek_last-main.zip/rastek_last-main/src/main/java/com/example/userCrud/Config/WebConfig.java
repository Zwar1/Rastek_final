package com.example.userCrud.Config;

public class WebConfig {
}
